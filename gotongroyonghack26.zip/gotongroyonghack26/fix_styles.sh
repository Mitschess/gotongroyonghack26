#!/bin/bash
find artifacts/lexiflow/src -name "*.tsx" -type f | while read file; do
  # Radii
  sed -i 's/rounded-2xl/rounded-xl/g' "$file"
  sed -i 's/rounded-xl/rounded-lg/g' "$file"
  
  # Gradients (remove them for a classic look)
  sed -i 's/bg-gradient-to-r from-indigo-900 via-slate-900 to-slate-950/bg-navy-900/g' "$file"
  sed -i 's/bg-gradient-to-r from-indigo-600 to-indigo-700/bg-navy-900/g' "$file"
  
  # Indigo to Navy/Gold
  sed -i 's/text-indigo-600/text-navy-900/g' "$file"
  sed -i 's/text-indigo-500/text-gold-600/g' "$file"
  sed -i 's/text-indigo-400/text-gold-500/g' "$file"
  sed -i 's/bg-indigo-600/bg-navy-900/g' "$file"
  sed -i 's/bg-indigo-500/bg-gold-500/g' "$file"
  sed -i 's/bg-indigo-50/bg-slate-50/g' "$file"
  sed -i 's/border-indigo-500/border-gold-500/g' "$file"
  sed -i 's/border-indigo-200/border-slate-200/g' "$file"
  sed -i 's/ring-indigo-500/ring-gold-500/g' "$file"
  sed -i 's/shadow-indigo-[^ ]*//g' "$file"
  
  # Empty class gaps
  sed -i 's/  */ /g' "$file"
  sed -i 's/ :[a-zA-Z0-9_-]*//g' "$file"
done

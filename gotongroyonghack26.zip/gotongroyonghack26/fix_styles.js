const fs = require('fs');
const path = require('path');

function processDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      processDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      
      // Remove dark: classes carefully
      content = content.replace(/dark:[a-zA-Z0-9_-]+\s?/g, '');
      
      // Radii
      content = content.replace(/rounded-2xl/g, 'rounded-xl');
      content = content.replace(/rounded-xl/g, 'rounded-lg');
      
      // Navy & Gold theme
      content = content.replace(/bg-gradient-to-r from-indigo-900 via-slate-900 to-slate-950/g, 'bg-navy-900');
      content = content.replace(/bg-gradient-to-r from-indigo-600 to-indigo-700/g, 'bg-navy-900');
      
      content = content.replace(/text-indigo-600/g, 'text-navy-900');
      content = content.replace(/text-indigo-500/g, 'text-gold-600');
      content = content.replace(/text-indigo-400/g, 'text-gold-500');
      
      content = content.replace(/bg-indigo-600/g, 'bg-navy-900');
      content = content.replace(/bg-indigo-500/g, 'bg-gold-500');
      content = content.replace(/bg-indigo-50/g, 'bg-slate-50');
      
      content = content.replace(/border-indigo-500/g, 'border-gold-500');
      content = content.replace(/border-indigo-200/g, 'border-slate-200');
      content = content.replace(/ring-indigo-500/g, 'ring-gold-500');
      
      // Replace specific colorful shadow things
      content = content.replace(/shadow-indigo-[a-zA-Z0-9_/-]+/g, 'shadow-sm');
      
      // Specific gradients in Sidebar
      content = content.replace(/bg-gradient-to-tr from-indigo-600 via-indigo-500 to-emerald-400 text-white/g, 'bg-gold-500 text-navy-950');

      fs.writeFileSync(fullPath, content);
    }
  }
}

processDir('artifacts/lexiflow/src/components');
processDir('artifacts/lexiflow/src');

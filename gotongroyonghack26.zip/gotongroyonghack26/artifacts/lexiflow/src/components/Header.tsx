'use client';

import React, { useState } from 'react';
import { 
  Bell, 
  Search, 
  Plus, 
  ShieldCheck, 
  UserCheck, 
  ChevronDown, 
  Sparkles, 
  CheckCircle2,
  Clock,
  FileText,
  Building2,
  Briefcase,
  Menu,
  MoreVertical
} from 'lucide-react';
import { User, UserRole, NotificationItem } from '../types/legal';
import { getAvatarColor } from '../lib/utils';

interface HeaderProps {
  currentUser: User;
  users: User[];
  onRoleChange: (user: User) => void;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onOpenNewWO: () => void;
  onOpenNewClient: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeTab: string;
  onMenuToggle?: () => void;
}

export default function Header({
  currentUser,
  users,
  onRoleChange,
  notifications,
  onMarkNotificationRead,
  onOpenNewWO,
  onOpenNewClient,
  searchQuery,
  setSearchQuery,
  activeTab,
  onMenuToggle
}: HeaderProps) {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileActions, setShowMobileActions] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const roleColors: Record<UserRole, string> = {
    'Super Admin': 'bg-status-purple text-white border-status-purple border',
    'Manager/Supervisor': 'bg-status-blue text-white border-status-blue border',
    'Legal Staff': 'bg-status-green text-white border-status-green border',
    'Admin': 'bg-status-yellow text-slate-900 border-status-yellow border',
    'Finance': 'bg-cyan-500/10 text-cyan-600 border-cyan-500/30',
    'Client': 'bg-status-red text-white border-status-red border'
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/80 px-3 md:px-6 backdrop-blur-md transition-colors gap-3">
      {/* Mobile Menu Toggle */}
      {onMenuToggle && (
        <button
          onClick={onMenuToggle}
          className="lg:hidden flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors"
        >
          <Menu className="h-5 w-5" />
        </button>
      )}

      {/* Search Input */}
      <div className="flex items-center gap-3 flex-1 min-w-0 max-w-md">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari project, client, dokumen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-accent-500 focus:outline-none focus:ring-2 focus:ring-accent-500/20 transition-all"
          />
        </div>
      </div>

      {/* Action Buttons & Profile Controls */}
      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        {/* Quick Action Buttons (Desktop) */}
        <div className="hidden md:flex items-center gap-2">
          <button
            onClick={onOpenNewClient}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-sm"
          >
            <Building2 className="h-3.5 w-3.5 text-accent-600" />
            + Client Baru
          </button>
          <button
            onClick={onOpenNewWO}
            className="flex items-center gap-1.5 rounded-lg bg-brand-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-brand-700 transition-all"
          >
            <Plus className="h-3.5 w-3.5" />
            Buat WO
          </button>
        </div>

        {/* Mobile Quick Actions Dropdown */}
        <div className="relative md:hidden">
          <button
            onClick={() => setShowMobileActions(!showMobileActions)}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors"
          >
            <MoreVertical className="h-4 w-4" />
          </button>
          {showMobileActions && (
            <div className="absolute right-0 mt-2 w-48 rounded-lg border border-slate-200 bg-white p-2 shadow-xl z-50">
              <button
                onClick={() => {
                  onOpenNewClient();
                  setShowMobileActions(false);
                }}
                className="flex w-full items-center gap-2 rounded-md px-3 py-3 text-xs font-medium text-slate-700 hover:bg-slate-50 min-h-[44px]"
              >
                <Building2 className="h-4 w-4 text-accent-600" />
                + Client Baru
              </button>
              <button
                onClick={() => {
                  onOpenNewWO();
                  setShowMobileActions(false);
                }}
                className="flex w-full items-center gap-2 rounded-md px-3 py-3 text-xs font-medium text-slate-700 hover:bg-slate-50 mt-1 min-h-[44px]"
              >
                <Plus className="h-4 w-4 text-brand-900" />
                Buat Work Order
              </button>
            </div>
          )}
        </div>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="fixed left-3 right-3 top-[4.5rem] md:absolute md:left-auto md:right-0 md:top-auto md:mt-2 md:w-96 rounded-lg border border-slate-200 bg-white p-4 shadow-xl z-50 transform origin-top-right transition-all">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 ">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-accent-600" />
                  <h4 className="text-sm font-bold text-slate-900 ">Notifikasi Sistem</h4>
                </div>
                <span className="rounded-full bg-slate-50 px-2 py-0.5 text-xs font-semibold text-brand-900 ">
                  {unreadCount} Baru
                </span>
              </div>

              <div className="mt-3 max-h-72 overflow-y-auto divide-y divide-slate-100 pr-1">
                {notifications.length === 0 ? (
                  <p className="py-6 text-center text-xs text-slate-500">Tidak ada notifikasi saat ini.</p>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => onMarkNotificationRead(notif.id)}
                      className={`cursor-pointer py-3 transition-colors ${
                        notif.read ? 'opacity-60' : 'bg-slate-50/40 px-2 rounded-lg'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <p className="text-xs font-semibold text-slate-900 ">{notif.title}</p>
                        <span className="text-[10px] text-slate-400">{notif.timestamp}</span>
                      </div>
                      <p className="mt-1 text-xs text-slate-600 ">{notif.message}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Role Switcher & User Profile */}
        <div className="relative">
          <button
            onClick={() => setShowRoleMenu(!showRoleMenu)}
            className="flex h-10 items-center gap-2.5 rounded-lg border border-slate-200 bg-slate-50 p-1.5 pr-2 md:pr-3 hover:bg-slate-100 transition-colors"
          >
            <div className={`flex h-7 w-7 md:h-8 md:w-8 shrink-0 items-center justify-center rounded-lg text-[10px] md:text-xs font-bold shadow-inner ${getAvatarColor(currentUser.name)}`}>
              {currentUser.name.substring(0, 2).toUpperCase()}
            </div>
            <div className="hidden md:block text-left">
              <p className="text-xs font-semibold text-slate-900 leading-tight truncate max-w-[120px]">{currentUser.name}</p>
              <span className={`mt-0.5 inline-block rounded border px-1.5 py-0.5 text-[9px] font-semibold ${roleColors[currentUser.role]}`}>
                {currentUser.role}
              </span>
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-slate-400 hidden sm:block" />
          </button>

          {/* Role Selection Menu */}
          {showRoleMenu && (
            <div className="fixed left-3 right-3 top-[4.5rem] md:absolute md:left-auto md:right-0 md:top-auto md:mt-2 md:w-72 rounded-lg border border-slate-200 bg-white p-3 shadow-xl z-50">
              <div className="px-2 py-1.5 border-b border-slate-100 ">
                <p className="text-[11px] font-semibold uppercase text-slate-400">Simulasi Akses User Role (RBAC)</p>
                <p className="text-xs text-slate-500">Pilih role untuk menguji tampilan & izin:</p>
              </div>

              <div className="mt-2 space-y-1">
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => {
                      onRoleChange(u);
                      setShowRoleMenu(false);
                    }}
                    className={`flex w-full min-h-[44px] items-center justify-between rounded-lg px-3 py-2.5 text-left text-xs transition-all ${
                      u.id === currentUser.id
                        ? 'bg-slate-50 font-bold text-brand-900 '
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p>{u.name}</p>
                      <span className="text-[10px] text-slate-400">{u.department}</span>
                    </div>
                    <span className={`rounded border px-1.5 py-0.5 text-[9px] font-semibold ${roleColors[u.role]}`}>
                      {u.role}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

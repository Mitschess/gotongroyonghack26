'use client';

import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Kanban, 
  List, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileText, 
  MessageSquare, 
  User, 
  Calendar, 
  ChevronRight, 
  X, 
  Send, 
  ArrowUpRight,
  ShieldCheck,
  Building2,
  Paperclip,
  TrendingUp,
  Check,
  Edit2
} from 'lucide-react';
import { 
  WorkOrder, 
  Client, 
  Service, 
  Task, 
  LegalDocument, 
  WorkNote, 
  UserRole,
  Priority,
  WorkOrderStatus 
} from '../types/legal';

interface WorkOrdersViewProps {
  workOrders: WorkOrder[];
  clients: Client[];
  services: Service[];
  tasks: Task[];
  documents: LegalDocument[];
  workNotes: WorkNote[];
  userRole: UserRole;
  currentUserId: string;
  onAddWorkOrder: (newWo: Partial<WorkOrder>) => void;
  onUpdateWorkOrderStatus: (woId: string, status: WorkOrderStatus) => void;
  onAdvanceWorkflowStage: (woId: string) => void;
  onAddTask: (newTask: Partial<Task>) => void;
  onUpdateTaskStatus: (taskId: string, status: Task['status']) => void;
  onAddWorkNote: (woId: string, content: string) => void;
  onRequestApproval: (woId: string, type: 'Stage Completion' | 'Document Signoff' | 'Final WO Completion') => void;
}

export default function WorkOrdersView({
  workOrders,
  clients,
  services,
  tasks,
  documents,
  workNotes,
  userRole,
  currentUserId,
  onAddWorkOrder,
  onUpdateWorkOrderStatus,
  onAdvanceWorkflowStage,
  onAddTask,
  onUpdateTaskStatus,
  onAddWorkNote,
  onRequestApproval
}: WorkOrdersViewProps) {
  const [viewMode, setViewMode] = useState<'board' | 'list' | 'timeline'>('board');
  const [groupByClient, setGroupByClient] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  
  // Selected Work Order Drawer State
  const [selectedWo, setSelectedWo] = useState<WorkOrder | null>(null);
  const [activeWoTab, setActiveWoTab] = useState<'workflow' | 'tasks' | 'documents' | 'notes'>('workflow');
  
  // Modal for new Work Order
  const [showAddModal, setShowAddModal] = useState(false);
  const [newWoForm, setNewWoForm] = useState({
    clientId: '',
    serviceId: '',
    picStaffId: 'usr-3',
    priority: 'Medium' as Priority,
    startDate: '2026-09-20',
    deadline: '2026-10-05',
    description: ''
  });

  // Modal for new Task inside Drawer
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [newTaskForm, setNewTaskForm] = useState({
    title: '',
    description: '',
    priority: 'Medium' as Priority,
    deadline: '2026-09-25'
  });

  // Note input state
  const [newNoteText, setNewNoteText] = useState('');

  // Filtering
  const filteredWorkOrders = workOrders.filter(wo => {
    const matchesSearch = wo.woNumber.toLowerCase().includes(searchFilter.toLowerCase()) ||
                          wo.clientName.toLowerCase().includes(searchFilter.toLowerCase()) ||
                          wo.serviceName.toLowerCase().includes(searchFilter.toLowerCase());
    const matchesStatus = statusFilter === 'all' || wo.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || wo.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const groupedWorkOrders = filteredWorkOrders.reduce<Record<string, WorkOrder[]>>((groups, wo) => {
    const key = wo.clientName || 'Tanpa Klien';
    groups[key] = groups[key] || [];
    groups[key].push(wo);
    return groups;
  }, {});

  const handleCreateWoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWoForm.clientId || !newWoForm.serviceId) return;

    const client = clients.find(c => c.id === newWoForm.clientId);
    const service = services.find(s => s.id === newWoForm.serviceId);

    onAddWorkOrder({
      clientId: newWoForm.clientId,
      clientName: client?.name || 'Client',
      serviceId: newWoForm.serviceId,
      serviceName: service?.name || 'Layanan Legal',
      picStaffId: newWoForm.picStaffId,
      picStaffName: 'Budi Santoso, S.H.',
      priority: newWoForm.priority,
      startDate: newWoForm.startDate,
      deadline: newWoForm.deadline,
      description: newWoForm.description,
      estimatedPrice: service?.price || 5000000,
      status: 'In Progress',
      currentStageIndex: 0,
      progressPercent: 15,
      workflow: service?.workflowStages.map((st, i) => ({
        stageId: st.id,
        stageName: st.name,
        status: i === 0 ? 'In Progress' : 'Pending'
      })) || []
    });

    setShowAddModal(false);
    setNewWoForm({
      clientId: '',
      serviceId: '',
      picStaffId: 'usr-3',
      priority: 'Medium',
      startDate: '2026-09-20',
      deadline: '2026-10-05',
      description: ''
    });
  };

  const handleAddTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWo || !newTaskForm.title) return;

    onAddTask({
      workOrderId: selectedWo.id,
      title: newTaskForm.title,
      description: newTaskForm.description,
      assigneeId: selectedWo.picStaffId,
      assigneeName: selectedWo.picStaffName,
      priority: newTaskForm.priority,
      deadline: newTaskForm.deadline,
      status: 'To Do',
      attachmentsCount: 0,
      notesCount: 0,
      createdAt: '2026-09-19'
    });

    setShowAddTaskModal(false);
    setNewTaskForm({ title: '', description: '', priority: 'Medium', deadline: '2026-09-25' });
  };

  const handleAddNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWo || !newNoteText.trim()) return;

    onAddWorkNote(selectedWo.id, newNoteText);
    setNewNoteText('');
  };

  const statusColumns: { status: WorkOrderStatus; title: string; color: string }[] = [
    { status: 'To Do', title: 'To Do / Antrean', color: 'border-slate-500 text-slate-400' },
    { status: 'In Progress', title: 'Dalam Proses', color: 'border-blue-500 text-blue-500' },
    { status: 'Review', title: 'Review Manager', color: 'border-amber-500 text-amber-500' },
    { status: 'Completed', title: 'Selesai', color: 'border-emerald-500 text-emerald-500' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
            <Kanban className="h-5 w-5 text-accent-600" /> Manajemen Work Order & Task Legal
          </h2>
          <p className="text-xs text-slate-500">Kelola berkas pekerjaan, penugasan staff, dan workflow perizinan</p>
        </div>

        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex items-center rounded-lg border border-slate-200 bg-white p-1">
            <button
              onClick={() => setViewMode('board')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                viewMode === 'board'
                  ? 'bg-brand-600 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Kanban className="h-3.5 w-3.5" /> Board
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                viewMode === 'list'
                  ? 'bg-brand-600 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <List className="h-3.5 w-3.5" /> Tabel List
            </button>
            <button
              onClick={() => setViewMode('timeline')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                viewMode === 'timeline'
                  ? 'bg-brand-600 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Calendar className="h-3.5 w-3.5" /> Timeline
            </button>
          </div>
          <button
            onClick={() => setGroupByClient(!groupByClient)}
            className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
              groupByClient
                ? 'border-brand-300 bg-brand-50 text-brand-700'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            {groupByClient ? 'Grup: Klien' : 'Kelompokkan'}
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-lg bg-brand-600 hover:bg-brand-700 px-4 py-2 text-xs font-bold text-white shadow-md transition-all"
          >
            <Plus className="h-4 w-4" /> Work Order Baru
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
        <div className="flex w-full items-center gap-2 md:w-auto md:flex-1 md:min-w-[240px]">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor WO, nama client, atau jenis layanan..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full bg-transparent text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none"
          />
        </div>

        <div className="flex w-full flex-wrap items-center gap-3 md:w-auto">
          <div className="flex items-center gap-1 text-xs text-slate-500">
            <Filter className="h-3.5 w-3.5" /> Status:
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-xs font-semibold text-slate-900 focus:outline-none"
            >
              <option value="all">Semua Status</option>
              <option value="To Do">To Do</option>
              <option value="In Progress">In Progress</option>
              <option value="Review">Review</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          <div className="flex items-center gap-1 text-xs text-slate-500">
            Priority:
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-xs font-semibold text-slate-900 focus:outline-none"
            >
              <option value="all">Semua Prioritas</option>
              <option value="Urgent">Urgent</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Timeline View */}
      {viewMode === 'timeline' ? (
        <div className="space-y-4">
          {Object.entries(groupByClient ? groupedWorkOrders : { 'Semua Work Order': filteredWorkOrders }).map(([groupName, items]) => (
            <section key={groupName} className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 bg-brand-50/60 px-4 py-3">
                <h3 className="text-sm font-bold text-brand-800">{groupName}</h3>
                <span className="rounded-full bg-white px-2 py-1 text-[10px] font-bold text-slate-500">{items.length} work order</span>
              </div>
              <div className="space-y-4 p-4">
                {items.map((wo) => (
                  <button key={wo.id} onClick={() => setSelectedWo(wo)} className="group block w-full text-left">
                    <div className="mb-1 flex items-center justify-between gap-3 text-xs">
                      <span className="truncate font-bold text-slate-800">{wo.woNumber} · {wo.serviceName}</span>
                      <span className="shrink-0 text-slate-500">{wo.deadline}</span>
                    </div>
                    <div className="h-7 overflow-hidden rounded-md bg-slate-100">
                      <div
                        className="flex h-full min-w-[8rem] items-center rounded-md bg-brand-500 px-3 text-[10px] font-bold text-white transition-all group-hover:bg-brand-600"
                        style={{ width: `${Math.max(18, wo.progressPercent)}%` }}
                      >
                        {wo.status} · {wo.progressPercent}%
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      ) : viewMode === 'board' ? (
        <div className="flex flex-nowrap overflow-x-auto pb-4 gap-4 snap-x snap-mandatory lg:grid lg:grid-cols-4 lg:overflow-visible lg:snap-none hide-scrollbar">
          {statusColumns.map((col) => {
            const colWorkOrders = filteredWorkOrders.filter(wo => wo.status === col.status);
            return (
              <div key={col.status} className="w-[85vw] sm:w-[300px] lg:w-auto shrink-0 snap-center rounded-lg border border-slate-200 bg-slate-50/50 p-3 flex flex-col min-h-[500px]">
                <div className={`flex items-center justify-between pb-3 border-b-2 ${col.color}`}>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 ">
                    {col.title}
                  </h3>
                  <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-bold text-slate-700 ">
                    {colWorkOrders.length}
                  </span>
                </div>

                <div className="mt-3 space-y-3 flex-1 overflow-y-auto">
                  {colWorkOrders.map((wo) => (
                    <div
                      key={wo.id}
                      onClick={() => setSelectedWo(wo)}
                      className="cursor-pointer rounded-lg border border-slate-200 bg-white p-4 shadow-sm hover:shadow-md transition-all hover:border-accent-500/50 group"
                    >
                      <div className="flex items-center justify-between text-[10px] font-sans font-medium font-bold text-brand-900 ">
                        <span>{wo.woNumber}</span>
                        <span className={`px-2 py-0.5 rounded ${
                          wo.priority === 'Urgent' ? 'bg-rose-500/10 text-rose-500 border border-rose-500/30' :
                          wo.priority === 'High' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/30' :
                          'bg-status-gray text-slate-900 border-status-gray border'
                        }`}>
                          {wo.priority}
                        </span>
                      </div>

                      <h4 className="mt-2 text-sm font-bold text-slate-900 group-hover:text-brand-900 transition-colors">
                        {wo.clientName}
                      </h4>
                      <p className="text-xs text-slate-500 line-clamp-1">{wo.serviceName}</p>

                      {/* Progress Bar */}
                      <div className="mt-3 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-slate-500">
                          <span>Tahap {wo.currentStageIndex + 1}/{wo.workflow.length}</span>
                          <span className="font-bold text-slate-900 ">{wo.progressPercent}%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-brand-500 h-full rounded-full transition-all"
                            style={{ width: `${wo.progressPercent}%` }}
                          />
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                        <span className="flex items-center gap-1 text-slate-600 font-medium">
                          <User className="h-3 w-3 text-accent-600" /> {wo.picStaffName.split(' ')[0]}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" /> {wo.deadline}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <>
          {/* Table - Desktop */}
          <div className="hidden md:block rounded-lg border border-slate-200 bg-white overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200 ">
                  <tr>
                    <th className="py-3.5 px-4">WO Number</th>
                    <th className="py-3.5 px-4">Klien / Perusahaan</th>
                    <th className="py-3.5 px-4">Jenis Layanan</th>
                    <th className="py-3.5 px-4">PIC Staff</th>
                    <th className="py-3.5 px-4">Priority</th>
                    <th className="py-3.5 px-4">Deadline</th>
                    <th className="py-3.5 px-4">Progress</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700 ">
                  {filteredWorkOrders.map((wo) => (
                    <tr key={wo.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-sans font-medium font-bold text-brand-900 ">{wo.woNumber}</td>
                      <td className="py-3 px-4 font-bold text-slate-900 ">{wo.clientName}</td>
                      <td className="py-3 px-4">{wo.serviceName}</td>
                      <td className="py-3 px-4">{wo.picStaffName}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-accent-500/10 text-accent-600">
                          {wo.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-sans font-medium">{wo.deadline}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-100 rounded-full h-1.5">
                            <div className="bg-brand-500 h-1.5 rounded-full" style={{ width: `${wo.progressPercent}%` }} />
                          </div>
                          <span className="font-bold">{wo.progressPercent}%</span>
                        </div>
                      </td>
                       <td className="py-3 px-4">
                         <select
                           value={wo.status}
                           onChange={(e) => onUpdateWorkOrderStatus(wo.id, e.target.value as WorkOrderStatus)}
                           className="rounded-full border-0 bg-status-blue px-2.5 py-1 text-[10px] font-bold text-white outline-none"
                         >
                           {(['To Do', 'In Progress', 'Review', 'Completed'] as WorkOrderStatus[]).map((status) => (
                             <option key={status} value={status}>{status}</option>
                           ))}
                         </select>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedWo(wo)}
                          className="rounded-lg bg-slate-50 px-2.5 py-1 text-xs font-bold text-brand-900 hover:bg-accent-100 transition-colors"
                        >
                          Detail Drawer
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Stacked Cards - Mobile */}
          <div className="md:hidden space-y-4">
            {filteredWorkOrders.map((wo) => (
              <div key={wo.id} className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm flex flex-col gap-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-sans font-medium text-[10px] font-bold text-brand-900">{wo.woNumber}</span>
                    <h4 className="font-bold text-slate-900 text-sm mt-0.5">{wo.clientName}</h4>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                     <select
                       value={wo.status}
                       onChange={(e) => onUpdateWorkOrderStatus(wo.id, e.target.value as WorkOrderStatus)}
                       className="rounded-full border-0 bg-status-blue px-2.5 py-1 text-[10px] font-bold text-white outline-none"
                     >
                       {(['To Do', 'In Progress', 'Review', 'Completed'] as WorkOrderStatus[]).map((status) => (
                         <option key={status} value={status}>{status}</option>
                       ))}
                     </select>
                    <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-accent-500/10 text-accent-600">
                      {wo.priority}
                    </span>
                  </div>
                </div>
                
                <div className="text-xs text-slate-500 space-y-1">
                  <p><span className="font-semibold">Layanan:</span> {wo.serviceName}</p>
                  <p><span className="font-semibold">PIC:</span> {wo.picStaffName}</p>
                  <p><span className="font-semibold">Deadline:</span> <span className="font-sans font-medium">{wo.deadline}</span></p>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                    <span>Progress:</span>
                    <span className="font-bold text-slate-900">{wo.progressPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-brand-500 h-full rounded-full transition-all"
                      style={{ width: `${wo.progressPercent}%` }}
                    />
                  </div>
                </div>

                <button
                  onClick={() => setSelectedWo(wo)}
                  className="w-full mt-2 rounded-lg bg-slate-50 hover:bg-accent-100 px-3 py-2 text-xs font-bold text-brand-900 transition-colors border border-slate-200"
                >
                  Lihat Detail Drawer
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Work Order Detail Drawer (FR-10 to FR-16, FR-30) */}
      {selectedWo && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white h-full overflow-y-auto shadow-2xl flex flex-col justify-between border-l border-slate-200 animate-in slide-in-from-right duration-300">
            {/* Drawer Header */}
            <div>
              <div className="p-4 md:p-6 border-b border-slate-200 flex items-start justify-between bg-slate-50 ">
                <div className="pr-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-sans font-medium text-xs font-bold text-brand-900 ">{selectedWo.woNumber}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-accent-500/10 text-accent-600">
                      {selectedWo.priority}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-500">
                      {selectedWo.status}
                    </span>
                  </div>
                  <h3 className="mt-2 text-base md:text-lg font-bold text-slate-900 break-words">{selectedWo.clientName}</h3>
                  <p className="text-xs text-slate-500 break-words">{selectedWo.serviceName}</p>
                </div>
                <button
                  onClick={() => setSelectedWo(null)}
                  className="rounded-full p-2 text-slate-400 hover:bg-slate-200 shrink-0"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Sub Navigation Tabs */}
              <div className="flex border-b border-slate-200 px-4 md:px-6 bg-white overflow-x-auto hide-scrollbar shrink-0">
                <button
                  onClick={() => setActiveWoTab('workflow')}
                  className={`py-3 px-3 md:px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
                    activeWoTab === 'workflow'
                      ? 'border-accent-500 text-brand-900 '
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Workflow & Status (FR-16)
                </button>
                <button
                  onClick={() => setActiveWoTab('tasks')}
                  className={`py-3 px-3 md:px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
                    activeWoTab === 'tasks'
                      ? 'border-accent-500 text-brand-900 '
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Tasks ({tasks.filter(t => t.workOrderId === selectedWo.id).length})
                </button>
                <button
                  onClick={() => setActiveWoTab('documents')}
                  className={`py-3 px-3 md:px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
                    activeWoTab === 'documents'
                      ? 'border-accent-500 text-brand-900 '
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Dokumen ({documents.filter(d => d.workOrderId === selectedWo.id).length})
                </button>
                <button
                  onClick={() => setActiveWoTab('notes')}
                  className={`py-3 px-3 md:px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
                    activeWoTab === 'notes'
                      ? 'border-accent-500 text-brand-900 '
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Catatan Pekerjaan (FR-30)
                </button>
              </div>

              {/* Drawer Tab Content */}
              <div className="p-6 space-y-6">
                {/* TAB 1: WORKFLOW ENGINE TRACKER */}
                {activeWoTab === 'workflow' && (
                  <div className="space-y-6">
                    {/* Status Change Control */}
                    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                      <label className="block text-xs font-bold text-slate-700 mb-2">
                        Ubah Status Work Order:
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {(['To Do', 'In Progress', 'Review', 'Completed'] as WorkOrderStatus[]).map((st) => (
                          <button
                            key={st}
                            onClick={() => {
                              onUpdateWorkOrderStatus(selectedWo.id, st);
                              setSelectedWo({ ...selectedWo, status: st });
                            }}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                              selectedWo.status === st
                                ? 'bg-brand-600 text-white shadow-sm'
                                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Interactive Visual Stage Tracker (FR-16) */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
                        Workflow Stage Tracker
                      </h4>
                      <div className="space-y-4 relative before:absolute before:left-3.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
                        {selectedWo.workflow.map((wf, idx) => {
                          const isCompleted = wf.status === 'Completed';
                          const isInProgress = wf.status === 'In Progress';

                          return (
                            <div key={wf.stageId} className="flex items-start gap-4 relative z-10">
                              <div className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold shrink-0 transition-all ${
                                isCompleted ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' :
                                isInProgress ? 'bg-brand-600 text-white animate-pulse' :
                                'bg-slate-200 text-slate-500'
                              }`}>
                                {isCompleted ? <Check className="h-4 w-4" /> : idx + 1}
                              </div>

                              <div className="flex-1 rounded-lg border border-slate-200 bg-white p-3 shadow-xs">
                                <div className="flex items-center justify-between">
                                  <h5 className="text-xs font-bold text-slate-900 ">{wf.stageName}</h5>
                                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                                    isCompleted ? 'bg-status-green text-white border-status-green border' :
                                    isInProgress ? 'bg-accent-500/10 text-accent-600' :
                                    'bg-slate-100 text-slate-400'
                                  }`}>
                                    {wf.status}
                                  </span>
                                </div>
                                {wf.completedAt && (
                                  <p className="mt-1 text-[11px] text-slate-400">
                                    Selesai oleh {wf.completedBy} pada {wf.completedAt}
                                  </p>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Advance Stage Button & Request Approval Button */}
                      <div className="mt-6 flex flex-col sm:flex-row gap-3">
                        <button
                          onClick={() => {
                            onAdvanceWorkflowStage(selectedWo.id);
                            // Refresh local view
                            const nextStageIndex = Math.min(selectedWo.currentStageIndex + 1, selectedWo.workflow.length - 1);
                            const updatedWf = [...selectedWo.workflow];
                            if (updatedWf[selectedWo.currentStageIndex]) {
                              updatedWf[selectedWo.currentStageIndex].status = 'Completed';
                              updatedWf[selectedWo.currentStageIndex].completedAt = '2026-09-19';
                              updatedWf[selectedWo.currentStageIndex].completedBy = 'Current User';
                            }
                            if (updatedWf[nextStageIndex]) {
                              updatedWf[nextStageIndex].status = 'In Progress';
                            }
                            setSelectedWo({
                              ...selectedWo,
                              currentStageIndex: nextStageIndex,
                              workflow: updatedWf,
                              progressPercent: Math.round(((nextStageIndex + 1) / updatedWf.length) * 100)
                            });
                          }}
                          className="flex-1 rounded-lg bg-brand-600 hover:bg-brand-700 py-2.5 text-xs font-bold text-white shadow-sm transition-all"
                        >
                          Lanjutkan Tahap Berikutnya →
                        </button>

                        <button
                          onClick={() => onRequestApproval(selectedWo.id, 'Stage Completion')}
                          className="rounded-lg border border-amber-500 text-amber-600 hover:bg-amber-500/10 py-2.5 px-4 text-xs font-bold transition-all"
                        >
                          Minta Approval Manager
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 2: TASKS MANAGEMENT */}
                {activeWoTab === 'tasks' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Daftar Tugas (Task Item)</h4>
                      <button
                        onClick={() => setShowAddTaskModal(true)}
                        className="flex items-center gap-1 rounded-lg bg-brand-600 text-white px-2.5 py-1 text-xs font-bold"
                      >
                        <Plus className="h-3.5 w-3.5" /> Tambah Task
                      </button>
                    </div>

                    <div className="space-y-3">
                      {tasks.filter(t => t.workOrderId === selectedWo.id).map((task) => (
                        <div key={task.id} className="rounded-lg border border-slate-200 bg-white p-4 shadow-xs">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h5 className="text-xs font-bold text-slate-900 ">{task.title}</h5>
                              <p className="mt-1 text-xs text-slate-500">{task.description}</p>
                            </div>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              task.status === 'Completed' ? 'bg-status-green text-white border-status-green border' :
                              task.status === 'In Progress' ? 'bg-accent-500/10 text-accent-600' :
                              'bg-slate-100 text-slate-400'
                            }`}>
                              {task.status}
                            </span>
                          </div>

                          <div className="mt-3 flex items-center justify-between pt-3 border-t border-slate-100 text-[11px]">
                            <span className="text-slate-500">Assignee: <strong className="text-slate-800 ">{task.assigneeName}</strong></span>
                            
                            <select
                              value={task.status}
                              onChange={(e) => onUpdateTaskStatus(task.id, e.target.value as Task['status'])}
                              className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-900 focus:outline-none"
                            >
                              <option value="To Do">To Do</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Review">Review</option>
                              <option value="Completed">Completed</option>
                            </select>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TAB 3: DOCUMENTS */}
                {activeWoTab === 'documents' && (
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Dokumen Terlampir</h4>
                    {documents.filter(d => d.workOrderId === selectedWo.id).map((doc) => (
                      <div key={doc.id} className="flex items-center justify-between rounded-lg border border-slate-200 p-3 bg-white ">
                        <div className="flex items-center gap-3">
                          <FileText className="h-5 w-5 text-accent-600" />
                          <div>
                            <p className="text-xs font-bold text-slate-900 ">{doc.title}</p>
                            <span className="text-[10px] text-slate-400">{doc.category} • Versi {doc.currentVersion} • {doc.fileSize}</span>
                          </div>
                        </div>
                        <span className="rounded bg-slate-50 px-2 py-0.5 text-[10px] font-bold text-brand-900 ">
                          {doc.accessLevel}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* TAB 4: WORK NOTES (FR-30) */}
                {activeWoTab === 'notes' && (
                  <div className="space-y-4">
                    <form onSubmit={handleAddNoteSubmit} className="space-y-2">
                      <textarea
                        rows={3}
                        placeholder="Tulis catatan perkembangan pekerjaan legalitas di sini..."
                        value={newNoteText}
                        onChange={(e) => setNewNoteText(e.target.value)}
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent-500/20"
                      />
                      <button
                        type="submit"
                        className="flex items-center gap-1.5 rounded-lg bg-brand-600 hover:bg-brand-700 text-white px-3.5 py-1.5 text-xs font-bold ml-auto"
                      >
                        <Send className="h-3.5 w-3.5" /> Simpan Catatan
                      </button>
                    </form>

                    <div className="space-y-3 pt-2">
                      {workNotes.filter(n => n.workOrderId === selectedWo.id).map((note) => (
                        <div key={note.id} className="rounded-lg border border-slate-200 p-3 bg-white ">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span className="font-bold text-slate-900 ">{note.authorName} ({note.authorRole})</span>
                            <span>{note.timestamp}</span>
                          </div>
                          <p className="mt-2 text-xs text-slate-700 whitespace-pre-wrap">{note.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Create Work Order */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-lg border border-slate-200 bg-white p-6 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 ">
              <h3 className="text-base font-bold text-slate-900 ">Buat Work Order Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateWoSubmit} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Pilih Klien:</label>
                <select
                  required
                  value={newWoForm.clientId}
                  onChange={(e) => setNewWoForm({ ...newWoForm, clientId: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:outline-none"
                >
                  <option value="">-- Pilih Klien --</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name} ({c.type})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Jenis Layanan Legalitas:</label>
                <select
                  required
                  value={newWoForm.serviceId}
                  onChange={(e) => setNewWoForm({ ...newWoForm, serviceId: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:outline-none"
                >
                  <option value="">-- Pilih Layanan --</option>
                  {services.map(s => (
                    <option key={s.id} value={s.id}>{s.name} (Est: {s.estimatedDays} hari)</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Priority:</label>
                  <select
                    value={newWoForm.priority}
                    onChange={(e) => setNewWoForm({ ...newWoForm, priority: e.target.value as Priority })}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:outline-none"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Deadline:</label>
                  <input
                    type="date"
                    required
                    value={newWoForm.deadline}
                    onChange={(e) => setNewWoForm({ ...newWoForm, deadline: e.target.value })}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Deskripsi & Catatan Awal:</label>
                <textarea
                  rows={3}
                  placeholder="Kebutuhan khusus atau catatan instruksi..."
                  value={newWoForm.description}
                  onChange={(e) => setNewWoForm({ ...newWoForm, description: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-lg border border-slate-200 px-4 py-2 font-semibold hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-brand-600 text-white px-5 py-2 font-bold hover:bg-brand-700 shadow-md"
                >
                  Buat Work Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Task inside Drawer */}
      {showAddTaskModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 ">
              <h3 className="text-sm font-bold text-slate-900 ">Tambah Task Baru</h3>
              <button onClick={() => setShowAddTaskModal(false)} className="text-slate-400">
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleAddTaskSubmit} className="mt-3 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Judul Task:</label>
                <input
                  type="text"
                  required
                  placeholder="Misal: Verifikasi KTP ke Dukcapil"
                  value={newTaskForm.title}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, title: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Deskripsi:</label>
                <textarea
                  rows={2}
                  value={newTaskForm.description}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, description: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2 text-xs focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddTaskModal(false)}
                  className="rounded-lg border px-3 py-1.5 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-brand-600 text-white px-4 py-1.5 font-bold"
                >
                  Simpan Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

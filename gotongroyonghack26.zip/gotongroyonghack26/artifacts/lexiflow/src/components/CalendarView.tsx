'use client';

import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  AlertTriangle, 
  Plus, 
  ChevronLeft, 
  ChevronRight, 
  X,
  FileCheck,
  CheckCircle2
} from 'lucide-react';
import { CalendarEvent, Priority } from '../types/legal';

interface CalendarViewProps {
  events: CalendarEvent[];
  onAddEvent: (newEvent: Partial<CalendarEvent>) => void;
}

export default function CalendarView({
  events,
  onAddEvent
}: CalendarViewProps) {
  const [currentMonth, setCurrentMonth] = useState('September 2026');
  const [showAddModal, setShowAddModal] = useState(false);

  const [title, setTitle] = useState('');
  const [date, setDate] = useState('2026-09-25');
  const [type, setType] = useState<CalendarEvent['type']>('Deadline');
  const [priority, setPriority] = useState<Priority>('High');

  // Days in September 2026 (Starts on Tuesday, Sept 1)
  const daysInMonth = Array.from({ length: 30 }, (_, i) => i + 1);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    onAddEvent({
      title,
      date,
      type,
      priority
    });

    setShowAddModal(false);
    setTitle('');
  };

  const getEventsForDay = (dayNum: number) => {
    const formattedDay = dayNum < 10 ? `0${dayNum}` : `${dayNum}`;
    const dateStr = `2026-09-${formattedDay}`;
    return events.filter(e => e.date === dateStr);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
            <CalendarIcon className="h-5 w-5 text-accent-600" /> Kalender Agenda & Deadline Management
          </h2>
          <p className="text-xs text-slate-500">Penjadwalan rapat notaris, deadline Kemenkumham, & pengajuan perizinan (FR-25 s.d. FR-27)</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-brand-600 hover:bg-brand-700 px-4 py-2 text-xs font-bold text-white shadow-md transition-all self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" /> Tambah Jadwal / Event
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Monthly Grid (2 Cols) */}
        <div className="lg:col-span-2 rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          {/* Calendar Header Month Control */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 ">
            <h3 className="text-base font-bold text-slate-900 ">{currentMonth}</h3>
            <div className="flex items-center gap-1">
              <button className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100">
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100">
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Days of Week */}
          <div className="mt-4 grid grid-cols-7 gap-1 text-center text-xs font-bold uppercase text-slate-400 pb-2 border-b border-slate-100 ">
            <div className="hidden sm:block">Minggu</div>
            <div className="hidden sm:block">Senin</div>
            <div className="hidden sm:block">Selasa</div>
            <div className="hidden sm:block">Rabu</div>
            <div className="hidden sm:block">Kamis</div>
            <div className="hidden sm:block">Jumat</div>
            <div className="hidden sm:block">Sabtu</div>
            
            <div className="sm:hidden">Mg</div>
            <div className="sm:hidden">Sn</div>
            <div className="sm:hidden">Sl</div>
            <div className="sm:hidden">Rb</div>
            <div className="sm:hidden">Km</div>
            <div className="sm:hidden">Jm</div>
            <div className="sm:hidden">Sb</div>
          </div>

          {/* Grid Cells */}
          <div className="mt-2 grid grid-cols-7 gap-1 min-h-[420px]">
            {/* Blank offset for September 2026 starting on Tuesday */}
            <div className="p-1 sm:p-2 border border-transparent" />
            <div className="p-1 sm:p-2 border border-transparent" />

            {daysInMonth.map((d) => {
              const dayEvents = getEventsForDay(d);
              const isToday = d === 19;

              return (
                <div
                  key={d}
                  className={`p-1 sm:p-1.5 rounded-lg border transition-all min-h-[50px] sm:min-h-[70px] flex flex-col sm:justify-between justify-start ${
                    isToday
                      ? 'border-accent-500 bg-slate-50/50'
                      : 'border-slate-100 bg-slate-50/40'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] gap-1">
                    <span className={`font-bold text-center sm:text-left ${isToday ? 'text-brand-900 ' : 'text-slate-700 '}`}>
                      {d}
                    </span>
                    {isToday && (
                      <span className="text-[9px] font-bold uppercase px-1 rounded bg-brand-600 text-white hidden sm:block">Hari ini</span>
                    )}
                  </div>

                  {/* Desktop Events */}
                  <div className="mt-1 space-y-1 overflow-hidden hidden sm:block">
                    {dayEvents.map((ev) => (
                      <div
                        key={ev.id}
                        className={`truncate rounded px-1.5 py-0.5 text-[9px] font-bold ${
                          ev.type === 'Deadline' ? 'bg-rose-500 text-white' :
                          ev.type === 'Meeting' ? 'bg-brand-600 text-white' :
                          'bg-amber-500 text-slate-950'
                        }`}
                        title={ev.title}
                      >
                        {ev.title}
                      </div>
                    ))}
                  </div>

                  {/* Mobile Events Dots */}
                  <div className="mt-1 flex flex-wrap gap-0.5 justify-center sm:hidden">
                    {dayEvents.map((ev) => (
                      <div
                        key={ev.id}
                        className={`h-1.5 w-1.5 rounded-full ${
                          ev.type === 'Deadline' ? 'bg-rose-500' :
                          ev.type === 'Meeting' ? 'bg-brand-600' :
                          'bg-amber-500'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Sidebar: Upcoming Deadlines & Event List */}
        <div className="space-y-4">
          <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-3 border-b border-slate-100 ">
              <Clock className="h-4 w-4 text-accent-600" /> Event & Deadline Mendatang
            </h3>

            <div className="mt-4 space-y-3">
              {events.map((ev) => (
                <div key={ev.id} className="rounded-lg border border-slate-200 p-3 bg-slate-50 ">
                  <div className="flex items-center justify-between text-[10px] font-bold">
                    <span className="px-2 py-0.5 rounded bg-accent-500/10 text-accent-600">{ev.type}</span>
                    <span className="font-sans font-medium text-slate-400">{ev.date}</span>
                  </div>
                  <h4 className="mt-2 text-xs font-bold text-slate-900 ">{ev.title}</h4>
                  {ev.relatedWoNumber && (
                    <p className="mt-1 text-[11px] font-sans font-medium text-accent-600">{ev.relatedWoNumber}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Modal: Add Event (FR-27) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 ">
              <h3 className="text-base font-bold text-slate-900 ">Tambah Event / Deadline</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Judul Agenda / Task:</label>
                <input
                  type="text"
                  required
                  placeholder="Misal: Penandatanganan Notaris PT Nusantara"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tanggal Event:</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Kategori:</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                  >
                    <option value="Deadline">Deadline</option>
                    <option value="Meeting">Meeting / Rapat</option>
                    <option value="Government Submission">Government Submission</option>
                    <option value="Task">Task</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-lg border px-4 py-2 font-semibold hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-brand-600 text-white px-5 py-2 font-bold shadow-md"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

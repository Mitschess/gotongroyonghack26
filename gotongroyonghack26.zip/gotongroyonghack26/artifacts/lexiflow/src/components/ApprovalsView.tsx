'use client';

import React, { useState } from 'react';
import { 
  CheckSquare, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  FileText, 
  UserCheck, 
  MessageSquare, 
  Check, 
  X,
  History
} from 'lucide-react';
import { ApprovalRequest, ApprovalStatus, UserRole } from '../types/legal';

interface ApprovalsViewProps {
  approvals: ApprovalRequest[];
  userRole: UserRole;
  currentUserName: string;
  onDecisionSubmit: (approvalId: string, status: ApprovalStatus, comments: string) => void;
}

export default function ApprovalsView({
  approvals,
  userRole,
  currentUserName,
  onDecisionSubmit
}: ApprovalsViewProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedApproval, setSelectedApproval] = useState<ApprovalRequest | null>(null);
  const [comments, setComments] = useState('');

  const filteredApprovals = approvals.filter(a => {
    return statusFilter === 'all' || a.status === statusFilter;
  });

  const isManagerOrAdmin = userRole === 'Manager/Supervisor' || userRole === 'Super Admin';

  const handleAction = (status: ApprovalStatus) => {
    if (!selectedApproval) return;
    onDecisionSubmit(selectedApproval.id, status, comments || (status === 'Approved' ? 'Disetujui.' : 'Perlu revisi.'));
    setSelectedApproval(null);
    setComments('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-accent-600" /> Pusat Persetujuan & Hirarki (Approval Management)
          </h2>
          <p className="text-xs text-slate-500">Review dokumen, verifikasi perizinan, dan persetujuan transisi tahap WO (FR-22 s.d. FR-24)</p>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 bg-white border border-slate-200 p-2 rounded-lg">
          <Clock className="h-4 w-4 text-amber-500" />
          <span>Status Filter:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-transparent font-bold text-slate-900 focus:outline-none"
          >
            <option value="all">Semua Status</option>
            <option value="Pending">Pending Review</option>
            <option value="Approved">Approved (Disetujui)</option>
            <option value="Rejected">Rejected (Ditolak)</option>
            <option value="Revision Required">Revision Required</option>
          </select>
        </div>
      </div>

      {/* Approvals Table - Desktop */}
      <div className="hidden md:block rounded-lg border border-slate-200 bg-white overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200 ">
              <tr>
                <th className="py-3.5 px-4">Req Number</th>
                <th className="py-3.5 px-4">Judul Work Order</th>
                <th className="py-3.5 px-4">Tipe Approval</th>
                <th className="py-3.5 px-4">Pemohon Staff</th>
                <th className="py-3.5 px-4">Waktu Pengajuan</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Aksi Review</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 ">
              {filteredApprovals.map((app) => {
                const statusBadge = {
                  Pending: 'bg-status-yellow text-slate-900 border-status-yellow border',
                  Approved: 'bg-status-green text-white border-status-green border',
                  Rejected: 'bg-status-red text-white border-status-red border',
                  'Revision Required': 'bg-status-purple text-white border-status-purple border'
                }[app.status];

                return (
                  <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-sans font-medium font-bold text-brand-900 ">{app.requestNumber}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 ">{app.workOrderTitle}</td>
                    <td className="py-3 px-4 font-semibold text-slate-600 ">{app.type}</td>
                    <td className="py-3 px-4">{app.requestedBy}</td>
                    <td className="py-3 px-4 text-slate-500">{app.requestedAt}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${statusBadge}`}>
                        {app.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {app.status === 'Pending' ? (
                        <button
                          onClick={() => setSelectedApproval(app)}
                          className="rounded-lg bg-brand-600 hover:bg-brand-700 text-white px-3 py-1 font-bold text-xs shadow-sm transition-all"
                        >
                          Review & Keputusan
                        </button>
                      ) : (
                        <button
                          onClick={() => setSelectedApproval(app)}
                          className="rounded-lg border border-slate-200 px-3 py-1 font-bold text-xs text-slate-600 hover:bg-slate-100"
                        >
                          Lihat History
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Approvals Stacked Cards - Mobile */}
      <div className="md:hidden space-y-4">
        {filteredApprovals.map((app) => {
          const statusBadge = {
            Pending: 'bg-status-yellow text-slate-900 border-status-yellow border',
            Approved: 'bg-status-green text-white border-status-green border',
            Rejected: 'bg-status-red text-white border-status-red border',
            'Revision Required': 'bg-status-purple text-white border-status-purple border'
          }[app.status];

          return (
            <div key={app.id} className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <span className="font-sans font-medium text-[10px] font-bold text-brand-900">{app.requestNumber}</span>
                  <h4 className="font-bold text-slate-900 text-sm mt-0.5">{app.workOrderTitle}</h4>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border whitespace-nowrap ${statusBadge}`}>
                  {app.status}
                </span>
              </div>
              
              <div className="text-xs text-slate-500 space-y-1">
                <p><span className="font-semibold">Tipe:</span> {app.type}</p>
                <p><span className="font-semibold">Pemohon:</span> {app.requestedBy}</p>
                <p><span className="font-semibold">Waktu:</span> {app.requestedAt}</p>
              </div>

              <div className="pt-2 border-t border-slate-100">
                {app.status === 'Pending' ? (
                  <button
                    onClick={() => setSelectedApproval(app)}
                    className="w-full rounded-lg bg-brand-600 hover:bg-brand-700 text-white px-3 py-2 font-bold text-xs shadow-sm transition-all"
                  >
                    Review & Keputusan
                  </button>
                ) : (
                  <button
                    onClick={() => setSelectedApproval(app)}
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 font-bold text-xs text-slate-600 hover:bg-slate-100"
                  >
                    Lihat History
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Decision / History Modal Drawer */}
      {selectedApproval && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-lg border border-slate-200 bg-white p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 ">
              <div>
                <span className="font-sans font-medium text-xs font-bold text-accent-600">{selectedApproval.requestNumber}</span>
                <h3 className="text-base font-bold text-slate-900 ">Review Pengajuan Approval</h3>
              </div>
              <button onClick={() => setSelectedApproval(null)} className="text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="rounded-lg bg-slate-50 p-4 border border-slate-200 space-y-1.5">
                <p><strong>Work Order:</strong> {selectedApproval.workOrderTitle} ({selectedApproval.workOrderNumber})</p>
                <p><strong>Tipe Persetujuan:</strong> {selectedApproval.type}</p>
                <p><strong>Diminta oleh:</strong> {selectedApproval.requestedBy} ({selectedApproval.requestedAt})</p>
                <p className="pt-2 text-slate-600 border-t border-slate-200 ">
                  <strong>Catatan Pemohon:</strong> "{selectedApproval.notes}"
                </p>
              </div>

              {selectedApproval.status !== 'Pending' ? (
                /* Display Decision History (FR-24) */
                <div className="rounded-lg border border-accent-500/20 bg-accent-500/5 p-4 space-y-2">
                  <h4 className="font-bold text-brand-900 flex items-center gap-1.5">
                    <History className="h-4 w-4" /> History Keputusan Supervisor
                  </h4>
                  <p><strong>Status Akhir:</strong> {selectedApproval.status}</p>
                  <p><strong>Approver:</strong> {selectedApproval.approverName}</p>
                  <p><strong>Waktu Keputusan:</strong> {selectedApproval.decisionDate}</p>
                  <p><strong>Komentar Supervisor:</strong> "{selectedApproval.decisionComments}"</p>
                </div>
              ) : (
                /* Manager Decision Form */
                <div className="space-y-3 pt-2">
                  {!isManagerOrAdmin && (
                    <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-600 font-semibold text-[11px]">
                      ⚠️ Catatan: Hanya role <strong>Manager/Supervisor</strong> atau <strong>Super Admin</strong> yang memiliki hak akses mengambil keputusan persetujuan. (Anda dapat mengubah role pada header).
                    </div>
                  )}

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Komentar / Instruksi Supervisor:</label>
                    <textarea
                      rows={3}
                      placeholder="Tuliskan alasan persetujuan atau catatan perbaikan..."
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <button
                      onClick={() => handleAction('Approved')}
                      className="flex items-center justify-center gap-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 text-xs shadow-sm"
                    >
                      <Check className="h-4 w-4" /> Disetujui
                    </button>
                    <button
                      onClick={() => handleAction('Revision Required')}
                      className="flex items-center justify-center gap-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 text-xs shadow-sm"
                    >
                      Minta Revisi
                    </button>
                    <button
                      onClick={() => handleAction('Rejected')}
                      className="flex items-center justify-center gap-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold py-2 text-xs shadow-sm"
                    >
                      <X className="h-4 w-4" /> Tolak
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  UserCheck, 
  Shield, 
  KeyRound, 
  Activity, 
  Search, 
  Filter,
  Lock,
  CheckCircle2
} from 'lucide-react';
import { ActivityLog, User } from '../types/legal';

interface AuditLogViewProps {
  activityLogs: ActivityLog[];
  users: User[];
}

export default function AuditLogView({
  activityLogs,
  users
}: AuditLogViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<'audit' | 'users'>('audit');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLogs = activityLogs.filter(l => {
    return l.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           l.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
           l.targetObject.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-accent-600" /> Audit Trail & System Administration
          </h2>
          <p className="text-xs text-slate-500">Pencatatan aktivitas sensitif pengguna, ip address, dan peran sistem (FR-37)</p>
        </div>

        {/* Subtab Toggle */}
        <div className="flex items-center rounded-lg border border-slate-200 bg-white p-1">
          <button
            onClick={() => setActiveSubTab('audit')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              activeSubTab === 'audit'
                ? 'bg-brand-600 text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Activity className="h-3.5 w-3.5" /> Log Aktivitas (Audit Trail)
          </button>
          <button
            onClick={() => setActiveSubTab('users')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              activeSubTab === 'users'
                ? 'bg-brand-600 text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <UserCheck className="h-3.5 w-3.5" /> Daftar User & Roles (RBAC)
          </button>
        </div>
      </div>

      {activeSubTab === 'audit' ? (
        <div className="space-y-4">
          {/* Search */}
          <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm flex items-center gap-2">
            <Search className="h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari log berdasarkan nama user, aksi, atau objek..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none"
            />
          </div>

          {/* Audit Logs Table - Desktop */}
          <div className="hidden md:block rounded-lg border border-slate-200 bg-white overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200 ">
                  <tr>
                    <th className="py-3.5 px-4">Pengguna (User)</th>
                    <th className="py-3.5 px-4">Role</th>
                    <th className="py-3.5 px-4">Tindakan / Action</th>
                    <th className="py-3.5 px-4">Objek / Target Data</th>
                    <th className="py-3.5 px-4">Waktu (Timestamp)</th>
                    <th className="py-3.5 px-4">IP Address</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700 ">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-bold text-slate-900 ">{log.userName}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-accent-500/10 text-accent-600">
                          {log.userRole}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-semibold text-brand-900 ">{log.action}</td>
                      <td className="py-3 px-4">{log.targetObject}</td>
                      <td className="py-3 px-4 font-sans font-medium text-slate-500">{log.timestamp}</td>
                      <td className="py-3 px-4 font-sans font-medium text-slate-400">{log.ipAddress || '127.0.0.1'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Audit Logs Stacked Cards - Mobile */}
          <div className="md:hidden space-y-4">
            {filteredLogs.map((log) => (
              <div key={log.id} className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm flex flex-col gap-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{log.userName}</h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-accent-500/10 text-accent-600 whitespace-nowrap">
                    {log.userRole}
                  </span>
                </div>
                
                <div className="text-xs text-slate-500 space-y-1">
                  <p><span className="font-semibold text-brand-900">{log.action}:</span> {log.targetObject}</p>
                  <p className="font-sans font-medium text-[10px] text-slate-400 mt-2">{log.timestamp} • {log.ipAddress || '127.0.0.1'}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Users & Roles Management Table - Desktop */
        <div className="hidden md:block rounded-lg border border-slate-200 bg-white overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200 ">
                <tr>
                  <th className="py-3.5 px-4">Nama Pengguna</th>
                  <th className="py-3.5 px-4">Email</th>
                  <th className="py-3.5 px-4">Role Hak Akses</th>
                  <th className="py-3.5 px-4">Departemen</th>
                  <th className="py-3.5 px-4">Izin Akses Utama</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 ">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900 ">{u.name}</td>
                    <td className="py-3 px-4 text-slate-500">{u.email}</td>
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-brand-600 text-white">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4">{u.department}</td>
                    <td className="py-3 px-4 text-slate-500">
                      {u.role === 'Super Admin' && 'Full Access All Modules'}
                      {u.role === 'Manager/Supervisor' && 'Approval, Task Assignment, Reports, WO'}
                      {u.role === 'Legal Staff' && 'View & Update Tasks, Upload Docs, Work Notes'}
                      {u.role === 'Admin' && 'Client Reg, Service Requests, Administrative'}
                      {u.role === 'Finance' && 'Billing, Invoicing, Payment Tracking'}
                      {u.role === 'Client' && 'View My WO Status, View Documents'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Users & Roles Stacked Cards - Mobile */}
      {activeSubTab === 'users' && (
        <div className="md:hidden space-y-4">
          {users.map((u) => (
            <div key={u.id} className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{u.name}</h4>
                  <p className="text-xs text-slate-500">{u.email}</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-brand-600 text-white whitespace-nowrap">
                  {u.role}
                </span>
              </div>
              
              <div className="text-xs text-slate-500 space-y-1">
                <p><span className="font-semibold">Dept:</span> {u.department}</p>
                <p className="text-[11px] leading-relaxed mt-2 pt-2 border-t border-slate-100">
                  <span className="font-semibold">Akses:</span>{' '}
                  {u.role === 'Super Admin' && 'Full Access All Modules'}
                  {u.role === 'Manager/Supervisor' && 'Approval, Task Assignment, Reports, WO'}
                  {u.role === 'Legal Staff' && 'View & Update Tasks, Upload Docs, Work Notes'}
                  {u.role === 'Admin' && 'Client Reg, Service Requests, Administrative'}
                  {u.role === 'Finance' && 'Billing, Invoicing, Payment Tracking'}
                  {u.role === 'Client' && 'View My WO Status, View Documents'}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

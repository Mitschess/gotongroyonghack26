'use client';

import React from 'react';
import { 
  LayoutDashboard, 
  FolderKanban, 
  Users, 
  BookOpen, 
  FileText, 
  CheckSquare, 
  Calendar, 
  CreditCard, 
  BarChart3, 
  ShieldAlert,
  Scale,
  Sparkles,
  X
} from 'lucide-react';
import { UserRole } from '../types/legal';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  pendingApprovalsCount: number;
  userRole: UserRole;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  pendingApprovalsCount,
  userRole,
  isMobileOpen,
  onCloseMobile
}: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff', 'Admin', 'Finance', 'Client'] },
    { id: 'workorders', label: 'Work Orders / Task', icon: FolderKanban, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff', 'Admin', 'Client'] },
    { id: 'clients', label: 'Klien & Perusahaan', icon: Users, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff', 'Admin', 'Finance'] },
    { id: 'services', label: 'Layanan Legalitas', icon: BookOpen, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff', 'Admin', 'Client'] },
    { id: 'documents', label: 'Dokumen Legal', icon: FileText, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff', 'Admin', 'Client'] },
    { id: 'approvals', label: 'Persetujuan', icon: CheckSquare, badge: pendingApprovalsCount, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff'] },
    { id: 'calendar', label: 'Kalender & Deadline', icon: Calendar, roles: ['Super Admin', 'Manager/Supervisor', 'Legal Staff', 'Admin'] },
    { id: 'finance', label: 'Keuangan & Invoice', icon: CreditCard, roles: ['Super Admin', 'Manager/Supervisor', 'Finance', 'Admin'] },
    { id: 'reports', label: 'Laporan Pekerjaan', icon: BarChart3, roles: ['Super Admin', 'Manager/Supervisor', 'Finance'] },
    { id: 'audit', label: 'Audit Trail & Admin', icon: ShieldAlert, roles: ['Super Admin', 'Manager/Supervisor'] },
  ];

  const filteredMenuItems = menuItems.filter(item => item.roles.includes(userRole));

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Content */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 border-r border-brand-800 bg-brand-900 text-slate-100 flex flex-col justify-between shrink-0 transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          {/* Brand Header */}
          <div className="flex h-16 items-center justify-between gap-3 px-6 border-b border-brand-800 shrink-0">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-sm bg-accent-500 text-brand-950 shadow-sm shrink-0">
                <Scale className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <h1 className="text-xl font-display font-bold tracking-tight text-white flex items-center gap-1.5 whitespace-nowrap">
                  LexiFlow <span className="text-[9px] font-sans font-bold uppercase tracking-widest px-1.5 py-0.5 rounded bg-accent-500/10 text-accent-400 border border-accent-500/20">PRO</span>
                </h1>
                <p className="text-[11px] text-slate-400 font-medium truncate">Legal Work OS</p>
              </div>
            </div>
            {onCloseMobile && (
              <button 
                onClick={onCloseMobile}
                className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-brand-800"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>

          {/* Navigation Section */}
          <div className="p-3 space-y-1">
            <p className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">Modul Utama</p>
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    if (onCloseMobile) onCloseMobile();
                  }}
                  className={`flex w-full min-h-[40px] items-center justify-between rounded-md px-3.5 py-2.5 text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-brand-800 text-white border border-brand-700 shadow-sm'
                      : 'text-slate-400 hover:bg-brand-800/50 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate pr-2">
                    <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && item.badge > 0 ? (
                    <span className="shrink-0 rounded-sm bg-accent-500 px-2 py-0.5 text-[10px] font-bold text-brand-950">
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer Info */}
        <div className="p-4 border-t border-brand-800 bg-brand-950/50 shrink-0">
          <div className="rounded-md border border-brand-800 bg-brand-900 p-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-accent-400">
              <Sparkles className="h-4 w-4 shrink-0" />
              <span className="truncate">SRS Compliance Ready</span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400 leading-tight line-clamp-2">
              Sistem terintegrasi alur kerja legalitas perusahaan & kepatuhan dokumen.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}

'use client';

import React, { useState } from 'react';
import { 
  CreditCard, 
  Plus, 
  DollarSign, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Download, 
  FileText, 
  X,
  Building2
} from 'lucide-react';
import { Invoice, InvoiceStatus, Client, WorkOrder } from '../types/legal';

interface FinanceViewProps {
  invoices: Invoice[];
  clients: Client[];
  workOrders: WorkOrder[];
  onAddInvoice: (newInvoice: Partial<Invoice>) => void;
  onRecordPayment: (invoiceId: string, amount: number, method: string) => void;
}

export default function FinanceView({
  invoices,
  clients,
  workOrders,
  onAddInvoice,
  onRecordPayment
}: FinanceViewProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // New Invoice Form
  const [clientId, setClientId] = useState('');
  const [workOrderId, setWorkOrderId] = useState('');
  const [amount, setAmount] = useState(5000000);
  const [dueDate, setDueDate] = useState('2026-10-01');

  // Payment Form
  const [payAmount, setPayAmount] = useState(0);
  const [payMethod, setPayMethod] = useState('Transfer Bank BCA');

  const filteredInvoices = invoices.filter(inv => {
    return statusFilter === 'all' || inv.status === statusFilter;
  });

  const totalInvoiced = invoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const totalPaid = invoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalUnpaid = totalInvoiced - totalPaid;

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId || !workOrderId) return;

    const client = clients.find(c => c.id === clientId);
    const wo = workOrders.find(w => w.id === workOrderId);

    const tax = amount * 0.11; // 11% PPN

    onAddInvoice({
      clientId,
      clientName: client?.name || 'Client',
      workOrderId,
      workOrderNumber: wo?.woNumber || 'WO-2026-0000',
      serviceName: wo?.serviceName || 'Layanan Legalitas',
      amount,
      taxAmount: tax,
      totalAmount: amount + tax,
      paidAmount: 0,
      issueDate: '2026-09-19',
      dueDate,
      status: 'Unpaid'
    });

    setShowAddModal(false);
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice || payAmount <= 0) return;

    onRecordPayment(selectedInvoice.id, Number(payAmount), payMethod);
    setShowPaymentModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-accent-600" /> Manajeman Keuangan & Invoicing Perizinan
          </h2>
          <p className="text-xs text-slate-500">Penerbitan tagihan, status pembayaran DP / pelunasan (FR-32 & FR-33)</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-brand-600 hover:bg-brand-700 px-4 py-2 text-xs font-bold text-white shadow-md transition-all self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" /> Terbitkan Invoice Baru
        </button>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-500">Total Nilai Tagihan (Total Invoiced)</p>
          <p className="mt-2 text-2xl font-black text-slate-900 ">
            Rp {totalInvoiced.toLocaleString('id-ID')}
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-emerald-600 ">Total Pembayaran Diterima</p>
          <p className="mt-2 text-2xl font-black text-emerald-600 ">
            Rp {totalPaid.toLocaleString('id-ID')}
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-rose-500">Sisa Piutang Belum Lunas</p>
          <p className="mt-2 text-2xl font-black text-rose-500">
            Rp {totalUnpaid.toLocaleString('id-ID')}
          </p>
        </div>
      </div>

      {/* Table - Desktop */}
      <div className="hidden md:block rounded-lg border border-slate-200 bg-white overflow-hidden shadow-sm">
        <div className="flex items-center justify-between p-4 border-b border-slate-100 ">
          <h3 className="text-sm font-bold text-slate-900 ">Daftar Tagihan & Invoice</h3>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Filter Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 font-semibold text-slate-900 focus:outline-none"
            >
              <option value="all">Semua Status</option>
              <option value="Paid">Paid (Lunas)</option>
              <option value="Partial">Partial (DP / Sebagian)</option>
              <option value="Unpaid">Unpaid (Belum Bayar)</option>
              <option value="Overdue">Overdue</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200 ">
              <tr>
                <th className="py-3.5 px-4">No. Invoice</th>
                <th className="py-3.5 px-4">Klien</th>
                <th className="py-3.5 px-4">Work Order</th>
                <th className="py-3.5 px-4">Total Tagihan</th>
                <th className="py-3.5 px-4">Sudah Dibayar</th>
                <th className="py-3.5 px-4">Jatuh Tempo</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 ">
              {filteredInvoices.map((inv) => {
                const statusBadge = {
                  Paid: 'bg-status-green text-white border-status-green border',
                  Partial: 'bg-status-yellow text-slate-900 border-status-yellow border',
                  Unpaid: 'bg-status-red text-white border-status-red border',
                  Overdue: 'bg-status-purple text-white border-status-purple border',
                  Cancelled: 'bg-status-gray text-slate-900 border-status-gray border'
                }[inv.status];

                return (
                  <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-sans font-medium font-bold text-brand-900 ">{inv.invoiceNumber}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 ">{inv.clientName}</td>
                    <td className="py-3 px-4 font-sans font-medium">{inv.workOrderNumber}</td>
                    <td className="py-3 px-4 font-bold">Rp {inv.totalAmount.toLocaleString('id-ID')}</td>
                    <td className="py-3 px-4 text-emerald-600 font-semibold">Rp {inv.paidAmount.toLocaleString('id-ID')}</td>
                    <td className="py-3 px-4 font-sans font-medium text-slate-500">{inv.dueDate}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${statusBadge}`}>
                        {inv.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {inv.status !== 'Paid' && (
                        <button
                          onClick={() => {
                            setSelectedInvoice(inv);
                            setPayAmount(inv.totalAmount - inv.paidAmount);
                            setShowPaymentModal(true);
                          }}
                          className="rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 font-bold text-xs shadow-sm"
                        >
                          Bayar
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stacked Cards - Mobile */}
      <div className="md:hidden space-y-4">
        <div className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 ">Daftar Tagihan & Invoice</h3>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Filter:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 font-semibold text-slate-900 focus:outline-none"
            >
              <option value="all">Semua Status</option>
              <option value="Paid">Paid (Lunas)</option>
              <option value="Partial">Partial (DP)</option>
              <option value="Unpaid">Unpaid (Belum Bayar)</option>
              <option value="Overdue">Overdue</option>
            </select>
          </div>
        </div>

        {filteredInvoices.map((inv) => {
          const statusBadge = {
            Paid: 'bg-status-green text-white border-status-green border',
            Partial: 'bg-status-yellow text-slate-900 border-status-yellow border',
            Unpaid: 'bg-status-red text-white border-status-red border',
            Overdue: 'bg-status-purple text-white border-status-purple border',
            Cancelled: 'bg-status-gray text-slate-900 border-status-gray border'
          }[inv.status];

          return (
            <div key={inv.id} className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <span className="font-sans font-medium text-[10px] font-bold text-brand-900">{inv.invoiceNumber}</span>
                  <h4 className="font-bold text-slate-900 text-sm mt-0.5">{inv.clientName}</h4>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border whitespace-nowrap ${statusBadge}`}>
                  {inv.status}
                </span>
              </div>
              
              <div className="text-xs text-slate-500 space-y-1">
                <p><span className="font-semibold">Work Order:</span> <span className="font-sans font-medium">{inv.workOrderNumber}</span></p>
                <p><span className="font-semibold">Jatuh Tempo:</span> <span className="font-sans font-medium">{inv.dueDate}</span></p>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="p-2 rounded bg-slate-50 border border-slate-100">
                    <p className="text-[10px]">Total Tagihan</p>
                    <p className="font-bold text-slate-900">Rp {inv.totalAmount.toLocaleString('id-ID')}</p>
                  </div>
                  <div className="p-2 rounded bg-emerald-50 border border-emerald-100">
                    <p className="text-[10px] text-emerald-700">Sudah Dibayar</p>
                    <p className="font-bold text-emerald-700">Rp {inv.paidAmount.toLocaleString('id-ID')}</p>
                  </div>
                </div>
              </div>

              {inv.status !== 'Paid' && (
                <div className="pt-2 border-t border-slate-100">
                  <button
                    onClick={() => {
                      setSelectedInvoice(inv);
                      setPayAmount(inv.totalAmount - inv.paidAmount);
                      setShowPaymentModal(true);
                    }}
                    className="w-full rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-2 font-bold text-xs shadow-sm transition-all"
                  >
                    Bayar Invoice
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Modal: Create Invoice */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 ">
              <h3 className="text-base font-bold text-slate-900 ">Terbitkan Invoice Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Pilih Klien:</label>
                <select
                  required
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                >
                  <option value="">-- Pilih Klien --</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Hubungkan Work Order:</label>
                <select
                  required
                  value={workOrderId}
                  onChange={(e) => setWorkOrderId(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                >
                  <option value="">-- Pilih Work Order --</option>
                  {workOrders.map(w => (
                    <option key={w.id} value={w.id}>{w.woNumber} - {w.serviceName}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nominal DPP (Rp):</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Jatuh Tempo:</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-lg border px-4 py-2 font-semibold hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-brand-600 text-white px-5 py-2 font-bold shadow-md"
                >
                  Terbitkan Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Record Payment */}
      {showPaymentModal && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 ">
              <h3 className="text-base font-bold text-slate-900 ">Catat Pembayaran Masuk</h3>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handlePaymentSubmit} className="mt-4 space-y-3 text-xs">
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200 ">
                <p><strong>Invoice:</strong> {selectedInvoice.invoiceNumber}</p>
                <p><strong>Klien:</strong> {selectedInvoice.clientName}</p>
                <p><strong>Sisa Tagihan:</strong> Rp {(selectedInvoice.totalAmount - selectedInvoice.paidAmount).toLocaleString('id-ID')}</p>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Jumlah Diterima (Rp):</label>
                <input
                  type="number"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Metode Pembayaran:</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 focus:outline-none"
                >
                  <option value="Transfer Bank BCA">Transfer Bank BCA</option>
                  <option value="Transfer Bank Mandiri">Transfer Bank Mandiri</option>
                  <option value="Virtual Account">Virtual Account</option>
                  <option value="Tunai / Cash">Tunai / Cash</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="rounded-lg border px-4 py-2 font-semibold hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 text-white px-5 py-2 font-bold shadow-md"
                >
                  Konfirmasi Pembayaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

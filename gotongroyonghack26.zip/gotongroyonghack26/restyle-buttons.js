import fs from 'fs';
import path from 'path';

const SRC_DIR = path.join(process.cwd(), 'artifacts/lexiflow/src/components');

function walk(dir, callback) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const p = path.join(dir, file);
    if (fs.statSync(p).isDirectory()) {
      walk(p, callback);
    } else {
      if (p.endsWith('.tsx') || p.endsWith('.ts')) {
        callback(p);
      }
    }
  }
}

walk(SRC_DIR, (filePath) => {
  if (filePath.endsWith('Sidebar.tsx')) return; // Skip Sidebar which wants dark brand bg
  
  let content = fs.readFileSync(filePath, 'utf-8');

  // Buttons, avatars, pills
  content = content.replace(/bg-brand-900/g, 'bg-brand-600');
  content = content.replace(/hover:bg-accent-500/g, 'hover:bg-brand-700');
  
  // Progress bars inner
  content = content.replace(/bg-brand-600 h-full/g, 'bg-brand-500 h-full');
  content = content.replace(/bg-brand-600 h-1\.5/g, 'bg-brand-500 h-1.5');
  
  fs.writeFileSync(filePath, content);
});

console.log('done buttons replace');

const fs = require('fs');
const path = require('path');

function processDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      processDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      
      content = content.replace(/font-serif font-bold font-serif font-bold font-bold/g, 'font-serif font-bold');
      content = content.replace(/font-serif font-bold font-serif font-bold/g, 'font-serif font-bold');
      content = content.replace(/font-serif font-serif/g, 'font-serif');
      content = content.replace(/text-2xl text-2xl/g, 'text-2xl');
      content = content.replace(/font-bold font-bold/g, 'font-bold');
      
      fs.writeFileSync(fullPath, content);
    }
  }
}

processDir('artifacts/lexiflow/src/components');

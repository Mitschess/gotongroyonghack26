const fs = require('fs');
const path = require('path');

function processDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      processDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      
      // Make all h2 tags (which are usually view headers) serif
      content = content.replace(/<h2 className="([^"]*)text-xl([^"]*font-bold[^"]*)"/g, '<h2 className="$1text-2xl font-serif font-bold$2"');
      content = content.replace(/<h2 className="([^"]*)text-2xl([^"]*font-bold[^"]*)"/g, '<h2 className="$1text-2xl font-serif font-bold$2"');

      fs.writeFileSync(fullPath, content);
    }
  }
}

processDir('artifacts/lexiflow/src/components');

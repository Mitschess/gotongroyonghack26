import fs from 'fs';
import path from 'path';

const SRC_DIR = path.join(process.cwd(), 'artifacts/lexiflow/src');

function walk(dir, callback) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const p = path.join(dir, file);
    if (fs.statSync(p).isDirectory()) {
      walk(p, callback);
    } else {
      if (p.endsWith('.tsx') || p.endsWith('.ts')) {
        callback(p);
      }
    }
  }
}

walk(SRC_DIR, (filePath) => {
  let content = fs.readFileSync(filePath, 'utf-8');

  // Colors
  content = content.replace(/navy-50\b/g, 'brand-50');
  content = content.replace(/navy-100\b/g, 'brand-100');
  content = content.replace(/navy-200\b/g, 'brand-200');
  content = content.replace(/navy-300\b/g, 'brand-300');
  content = content.replace(/navy-400\b/g, 'brand-400');
  content = content.replace(/navy-500\b/g, 'brand-500');
  content = content.replace(/navy-600\b/g, 'brand-600');
  content = content.replace(/navy-700\b/g, 'brand-700');
  content = content.replace(/navy-800\b/g, 'brand-800');
  content = content.replace(/navy-900\b/g, 'brand-900');
  content = content.replace(/navy-950\b/g, 'brand-950');

  content = content.replace(/gold-50\b/g, 'accent-50');
  content = content.replace(/gold-100\b/g, 'accent-100');
  content = content.replace(/gold-200\b/g, 'accent-200');
  content = content.replace(/gold-300\b/g, 'accent-300');
  content = content.replace(/gold-400\b/g, 'accent-400');
  content = content.replace(/gold-500\b/g, 'accent-500');
  content = content.replace(/gold-600\b/g, 'accent-600');
  content = content.replace(/gold-700\b/g, 'accent-700');
  content = content.replace(/gold-800\b/g, 'accent-800');
  content = content.replace(/gold-900\b/g, 'accent-900');

  // Typography
  content = content.replace(/font-serif/g, 'font-display');
  content = content.replace(/font-mono/g, 'font-sans font-medium');

  // Update Status Badges to use Monday-style colors
  // We'll just replace the whole blocks or carefully regex them.
  // Instead of complex regex, let's just write simple generic replacers for tailwind color classes in those maps.
  
  // Status Maps in FinanceView, ApprovalsView, DashboardView, WorkOrdersView etc.
  content = content.replace(/'bg-emerald-\d+\/\d+ text-emerald-\d+( border-emerald-\d+\/\d+)?'/g, "'bg-status-green text-white border-status-green border'");
  content = content.replace(/'bg-emerald-\d+\/\d+ text-emerald-\d+ '/g, "'bg-status-green text-white '");
  content = content.replace(/'bg-amber-\d+\/\d+ text-amber-\d+( border-amber-\d+\/\d+)?'/g, "'bg-status-yellow text-slate-900 border-status-yellow border'");
  content = content.replace(/'bg-amber-\d+\/\d+ text-amber-\d+ '/g, "'bg-status-yellow text-slate-900 '");
  content = content.replace(/'bg-rose-\d+\/\d+ text-rose-\d+( border-rose-\d+\/\d+)?'/g, "'bg-status-red text-white border-status-red border'");
  content = content.replace(/'bg-rose-\d+\/\d+ text-rose-\d+ '/g, "'bg-status-red text-white '");
  content = content.replace(/'bg-blue-\d+\/\d+ text-blue-\d+( border-blue-\d+\/\d+)?'/g, "'bg-status-blue text-white border-status-blue border'");
  content = content.replace(/'bg-blue-\d+\/\d+ text-blue-\d+ '/g, "'bg-status-blue text-white '");
  content = content.replace(/'bg-purple-\d+\/\d+ text-purple-\d+( border-purple-\d+\/\d+)?'/g, "'bg-status-purple text-white border-status-purple border'");
  content = content.replace(/'bg-purple-\d+\/\d+ text-purple-\d+ '/g, "'bg-status-purple text-white '");
  content = content.replace(/'bg-slate-\d+\/\d+ text-slate-\d+( border-slate-\d+\/\d+)?'/g, "'bg-status-gray text-slate-900 border-status-gray border'");
  content = content.replace(/'bg-slate-\d+\/\d+ text-slate-\d+ '/g, "'bg-status-gray text-slate-900 '");
  content = content.replace(/'bg-gray-\d+\/\d+ text-gray-\d+( border-gray-\d+\/\d+)?'/g, "'bg-status-gray text-slate-900 border-status-gray border'");
  content = content.replace(/'bg-gray-\d+\/\d+ text-gray-\d+ '/g, "'bg-status-gray text-slate-900 '");
  content = content.replace(/'bg-accent-500\/10 text-brand-900 border-accent-500\/30'/g, "'bg-status-blue text-white border-status-blue border'");

  // Specific overrides for 'Medium' which mapped to gold in DashboardView
  // In DashboardView: Medium: 'bg-gold-500/10 text-navy-900 border-gold-500/30'
  // After replace it becomes 'bg-accent-500/10 text-brand-900 border-accent-500/30'
  
  fs.writeFileSync(filePath, content);
});

console.log('done');
